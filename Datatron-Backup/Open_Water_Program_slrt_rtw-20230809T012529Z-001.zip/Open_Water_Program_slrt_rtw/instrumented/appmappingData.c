#include "slrtappmapping.h"
#include "./maps/Open_Water_Program.map"



const AppMapInfo appInfo[] = 
{
	{ /* Idx 0, <Open_Water_Program> */
		{ /* SignalMapInfo */
			Open_Water_Program_BIOMAP,
			Open_Water_Program_LBLMAP,
			Open_Water_Program_SIDMAP,
			Open_Water_Program_SBIO,
			Open_Water_Program_SLBL,
			{0,7},
			6,
		},
		{ /* ParamMapInfo */
			Open_Water_Program_PTIDSMAP,
			Open_Water_Program_PTNAMESMAP,
			Open_Water_Program_SPTMAP,
			{0,14},
			15,
		},
		"Open_Water_Program",
		"",
		"Open_Water_Program",
		1,
		Open_Water_Program_dtmap,
	},
};
int getNumRef(void){
	 return(sizeof(appInfo) / sizeof(AppMapInfo));
}