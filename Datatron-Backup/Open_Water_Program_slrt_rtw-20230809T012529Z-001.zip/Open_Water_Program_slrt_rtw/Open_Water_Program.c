/*
 * Open_Water_Program.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Open_Water_Program".
 *
 * Model version              : 1.540
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Wed Mar  8 13:12:13 2023
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rt_logging_mmi.h"
#include "Open_Water_Program_capi.h"
#include "Open_Water_Program.h"
#include "Open_Water_Program_private.h"

/* Block signals (auto storage) */
B_Open_Water_Program_T Open_Water_Program_B;

/* Block states (auto storage) */
DW_Open_Water_Program_T Open_Water_Program_DW;

/* Real-time model */
RT_MODEL_Open_Water_Program_T Open_Water_Program_M_;
RT_MODEL_Open_Water_Program_T *const Open_Water_Program_M =
  &Open_Water_Program_M_;

/* Model output function */
static void Open_Water_Program_output(void)
{
  /* S-Function (scblock): '<S1>/S-Function' */
  /* ok to acquire for <S1>/S-Function */
  Open_Water_Program_DW.SFunction_IWORK.AcquireOK = 1;

  /* S-Function (adnipcim): '<Root>/PCI-6251 AD' */

  /* Level2 S-Function Block: '<Root>/PCI-6251 AD' (adnipcim) */
  {
    SimStruct *rts = Open_Water_Program_M->childSfunctions[0];
    sfcnOutputs(rts,0);
  }

  /* SignalConversion: '<Root>/ConcatBufferAtVector Concatenate5In1' */
  Open_Water_Program_B.VectorConcatenate5[0] = Open_Water_Program_B.PCI6251AD;

  /* Memory: '<Root>/Memory5' */
  Open_Water_Program_B.Memory5 = Open_Water_Program_DW.Memory5_PreviousInput;

  /* MATLAB Function: '<Root>/MATLAB Function1' */
  /* MATLAB Function 'MATLAB Function1': '<S2>:1' */
  if (Open_Water_Program_B.PCI6251AD >= 0.2) {
    /* '<S2>:1:8' */
    /* '<S2>:1:9' */
    Open_Water_Program_B.y1 = Open_Water_Program_B.Memory5 + 1.0;
    if (Open_Water_Program_B.Memory5 > 5.0) {
      /* '<S2>:1:10' */
      /* '<S2>:1:11' */
      Open_Water_Program_B.VectorConcatenate5[1] = 1.0;
    } else {
      /* '<S2>:1:13' */
      Open_Water_Program_B.VectorConcatenate5[1] = 0.0;
    }
  } else {
    /* '<S2>:1:16' */
    Open_Water_Program_B.VectorConcatenate5[1] = 0.0;

    /* '<S2>:1:17' */
    Open_Water_Program_B.y1 = 0.0;
  }

  /* End of MATLAB Function: '<Root>/MATLAB Function1' */

  /* MATLAB Function: '<Root>/MATLAB Function4' */
  /* MATLAB Function 'MATLAB Function4': '<S3>:1' */
  /* '<S3>:1:4' */
  Open_Water_Program_B.Water = 1.0;

  /* S-Function (donipcim): '<Root>/PCI-6251 DO2' */

  /* Level2 S-Function Block: '<Root>/PCI-6251 DO2' (donipcim) */
  {
    SimStruct *rts = Open_Water_Program_M->childSfunctions[1];
    sfcnOutputs(rts,0);
  }
}

/* Model update function */
static void Open_Water_Program_update(void)
{
  /* Update for Memory: '<Root>/Memory5' */
  Open_Water_Program_DW.Memory5_PreviousInput = Open_Water_Program_B.y1;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++Open_Water_Program_M->Timing.clockTick0)) {
    ++Open_Water_Program_M->Timing.clockTickH0;
  }

  Open_Water_Program_M->Timing.t[0] = Open_Water_Program_M->Timing.clockTick0 *
    Open_Water_Program_M->Timing.stepSize0 +
    Open_Water_Program_M->Timing.clockTickH0 *
    Open_Water_Program_M->Timing.stepSize0 * 4294967296.0;
}

/* Model initialize function */
static void Open_Water_Program_initialize(void)
{
  /* Start for S-Function (scblock): '<S1>/S-Function' */

  /* S-Function Block: <S1>/S-Function (scblock) */
  {
    int i;
    if ((i = rl32eScopeExists(1)) == 0) {
      if ((i = rl32eDefScope(1,2)) != 0) {
        printf("Error creating scope 1\n");
      } else {
        rl32eAddSignal(1, rl32eGetSignalNo("Vector Concatenate5/s1"));
        rl32eAddSignal(1, rl32eGetSignalNo("Vector Concatenate5/s2"));
        rl32eSetScope(1, 4, 500);
        rl32eSetScope(1, 5, 0);
        rl32eSetScope(1, 6, 1);
        rl32eSetScope(1, 0, 0);
        rl32eSetScope(1, 3, rl32eGetSignalNo("Vector Concatenate5/s1"));
        rl32eSetScope(1, 1, 0.0);
        rl32eSetScope(1, 2, 0);
        rl32eSetScope(1, 9, 0);
        rl32eSetTargetScope(1, 11, -1.0);
        rl32eSetTargetScope(1, 10, 5.0);
        xpceScopeAcqOK(1, &Open_Water_Program_DW.SFunction_IWORK.AcquireOK);
      }
    }

    if (i) {
      rl32eRestartAcquisition(1);
    }
  }

  /* Start for S-Function (adnipcim): '<Root>/PCI-6251 AD' */
  /* Level2 S-Function Block: '<Root>/PCI-6251 AD' (adnipcim) */
  {
    SimStruct *rts = Open_Water_Program_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (donipcim): '<Root>/PCI-6251 DO2' */
  /* Level2 S-Function Block: '<Root>/PCI-6251 DO2' (donipcim) */
  {
    SimStruct *rts = Open_Water_Program_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* InitializeConditions for Memory: '<Root>/Memory5' */
  Open_Water_Program_DW.Memory5_PreviousInput =
    Open_Water_Program_P.Memory5_InitialCondition;
}

/* Model terminate function */
static void Open_Water_Program_terminate(void)
{
  /* Terminate for S-Function (adnipcim): '<Root>/PCI-6251 AD' */
  /* Level2 S-Function Block: '<Root>/PCI-6251 AD' (adnipcim) */
  {
    SimStruct *rts = Open_Water_Program_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (donipcim): '<Root>/PCI-6251 DO2' */
  /* Level2 S-Function Block: '<Root>/PCI-6251 DO2' (donipcim) */
  {
    SimStruct *rts = Open_Water_Program_M->childSfunctions[1];
    sfcnTerminate(rts);
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  Open_Water_Program_output();
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  Open_Water_Program_update();
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  Open_Water_Program_initialize();
}

void MdlTerminate(void)
{
  Open_Water_Program_terminate();
}

/* Registration function */
RT_MODEL_Open_Water_Program_T *Open_Water_Program(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)Open_Water_Program_M, 0,
                sizeof(RT_MODEL_Open_Water_Program_T));
  rtsiSetSolverName(&Open_Water_Program_M->solverInfo,"FixedStepDiscrete");
  Open_Water_Program_M->solverInfoPtr = (&Open_Water_Program_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = Open_Water_Program_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    Open_Water_Program_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    Open_Water_Program_M->Timing.sampleTimes =
      (&Open_Water_Program_M->Timing.sampleTimesArray[0]);
    Open_Water_Program_M->Timing.offsetTimes =
      (&Open_Water_Program_M->Timing.offsetTimesArray[0]);

    /* task periods */
    Open_Water_Program_M->Timing.sampleTimes[0] = (0.001);

    /* task offsets */
    Open_Water_Program_M->Timing.offsetTimes[0] = (0.0);
  }

  rtmSetTPtr(Open_Water_Program_M, &Open_Water_Program_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = Open_Water_Program_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    Open_Water_Program_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(Open_Water_Program_M, -1);
  Open_Water_Program_M->Timing.stepSize0 = 0.001;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    Open_Water_Program_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(Open_Water_Program_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(Open_Water_Program_M->rtwLogInfo, (NULL));
    rtliSetLogT(Open_Water_Program_M->rtwLogInfo, "tout");
    rtliSetLogX(Open_Water_Program_M->rtwLogInfo, "");
    rtliSetLogXFinal(Open_Water_Program_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(Open_Water_Program_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(Open_Water_Program_M->rtwLogInfo, 2);
    rtliSetLogMaxRows(Open_Water_Program_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(Open_Water_Program_M->rtwLogInfo, 1);
    rtliSetLogY(Open_Water_Program_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(Open_Water_Program_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(Open_Water_Program_M->rtwLogInfo, (NULL));
  }

  Open_Water_Program_M->solverInfoPtr = (&Open_Water_Program_M->solverInfo);
  Open_Water_Program_M->Timing.stepSize = (0.001);
  rtsiSetFixedStepSize(&Open_Water_Program_M->solverInfo, 0.001);
  rtsiSetSolverMode(&Open_Water_Program_M->solverInfo, SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  Open_Water_Program_M->blockIO = ((void *) &Open_Water_Program_B);
  (void) memset(((void *) &Open_Water_Program_B), 0,
                sizeof(B_Open_Water_Program_T));

  /* parameters */
  Open_Water_Program_M->defaultParam = ((real_T *)&Open_Water_Program_P);

  /* states (dwork) */
  Open_Water_Program_M->dwork = ((void *) &Open_Water_Program_DW);
  (void) memset((void *)&Open_Water_Program_DW, 0,
                sizeof(DW_Open_Water_Program_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  Open_Water_Program_InitializeDataMapInfo();

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &Open_Water_Program_M->NonInlinedSFcns.sfcnInfo;
    Open_Water_Program_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(Open_Water_Program_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &Open_Water_Program_M->Sizes.numSampTimes);
    Open_Water_Program_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (Open_Water_Program_M)[0]);
    rtssSetTPtrPtr(sfcnInfo,Open_Water_Program_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(Open_Water_Program_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(Open_Water_Program_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (Open_Water_Program_M));
    rtssSetStepSizePtr(sfcnInfo, &Open_Water_Program_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(Open_Water_Program_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &Open_Water_Program_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &Open_Water_Program_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &Open_Water_Program_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &Open_Water_Program_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &Open_Water_Program_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &Open_Water_Program_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &Open_Water_Program_M->solverInfoPtr);
  }

  Open_Water_Program_M->Sizes.numSFcns = (2);

  /* register each child */
  {
    (void) memset((void *)&Open_Water_Program_M->
                  NonInlinedSFcns.childSFunctions[0], 0,
                  2*sizeof(SimStruct));
    Open_Water_Program_M->childSfunctions =
      (&Open_Water_Program_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    Open_Water_Program_M->childSfunctions[0] =
      (&Open_Water_Program_M->NonInlinedSFcns.childSFunctions[0]);
    Open_Water_Program_M->childSfunctions[1] =
      (&Open_Water_Program_M->NonInlinedSFcns.childSFunctions[1]);

    /* Level2 S-Function Block: Open_Water_Program/<Root>/PCI-6251 AD (adnipcim) */
    {
      SimStruct *rts = Open_Water_Program_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        Open_Water_Program_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        Open_Water_Program_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = Open_Water_Program_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Open_Water_Program_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Open_Water_Program_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Open_Water_Program_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Open_Water_Program_M->NonInlinedSFcns.methods2
                           [0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Open_Water_Program_M->NonInlinedSFcns.methods3
                           [0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Open_Water_Program_M->NonInlinedSFcns.methods4
                           [0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Open_Water_Program_M->
                         NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &Open_Water_Program_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &Open_Water_Program_B.PCI6251AD));
        }
      }

      /* path info */
      ssSetModelName(rts, "PCI-6251 AD");
      ssSetPath(rts, "Open_Water_Program/PCI-6251 AD");
      ssSetRTModel(rts,Open_Water_Program_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Open_Water_Program_P.PCI6251AD_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)Open_Water_Program_P.PCI6251AD_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)Open_Water_Program_P.PCI6251AD_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)Open_Water_Program_P.PCI6251AD_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)Open_Water_Program_P.PCI6251AD_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)Open_Water_Program_P.PCI6251AD_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)Open_Water_Program_P.PCI6251AD_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &Open_Water_Program_DW.PCI6251AD_IWORK[0]);
      ssSetPWork(rts, (void **) &Open_Water_Program_DW.PCI6251AD_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 41);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &Open_Water_Program_DW.PCI6251AD_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &Open_Water_Program_DW.PCI6251AD_PWORK);
      }

      /* registration */
      adnipcim(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: Open_Water_Program/<Root>/PCI-6251 DO2 (donipcim) */
    {
      SimStruct *rts = Open_Water_Program_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        Open_Water_Program_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        Open_Water_Program_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = Open_Water_Program_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &Open_Water_Program_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &Open_Water_Program_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, Open_Water_Program_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &Open_Water_Program_M->NonInlinedSFcns.methods2
                           [1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &Open_Water_Program_M->NonInlinedSFcns.methods3
                           [1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &Open_Water_Program_M->NonInlinedSFcns.methods4
                           [1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &Open_Water_Program_M->
                         NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &Open_Water_Program_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);

        /* port 0 */
        {
          real_T const **sfcnUPtrs = (real_T const **)
            &Open_Water_Program_M->NonInlinedSFcns.Sfcn1.UPtrs0;
          sfcnUPtrs[0] = &Open_Water_Program_B.Water;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "PCI-6251 DO2");
      ssSetPath(rts, "Open_Water_Program/PCI-6251 DO2");
      ssSetRTModel(rts,Open_Water_Program_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)Open_Water_Program_P.PCI6251DO2_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)Open_Water_Program_P.PCI6251DO2_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)Open_Water_Program_P.PCI6251DO2_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)Open_Water_Program_P.PCI6251DO2_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)Open_Water_Program_P.PCI6251DO2_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)Open_Water_Program_P.PCI6251DO2_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)Open_Water_Program_P.PCI6251DO2_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &Open_Water_Program_DW.PCI6251DO2_IWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &Open_Water_Program_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &Open_Water_Program_DW.PCI6251DO2_IWORK);
      }

      /* registration */
      donipcim(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }
  }

  /* Initialize Sizes */
  Open_Water_Program_M->Sizes.numContStates = (0);/* Number of continuous states */
  Open_Water_Program_M->Sizes.numY = (0);/* Number of model outputs */
  Open_Water_Program_M->Sizes.numU = (0);/* Number of model inputs */
  Open_Water_Program_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  Open_Water_Program_M->Sizes.numSampTimes = (1);/* Number of sample times */
  Open_Water_Program_M->Sizes.numBlocks = (10);/* Number of blocks */
  Open_Water_Program_M->Sizes.numBlockIO = (5);/* Number of block outputs */
  Open_Water_Program_M->Sizes.numBlockPrms = (43);/* Sum of parameter "widths" */
  return Open_Water_Program_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
