/*
 * Open_Water_Program_data.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Open_Water_Program".
 *
 * Model version              : 1.540
 * Simulink Coder version : 8.13 (R2017b) 24-Jul-2017
 * C source code generated on : Wed Mar  8 13:12:13 2023
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Open_Water_Program.h"
#include "Open_Water_Program_private.h"

/* Block parameters (auto storage) */
P_Open_Water_Program_T Open_Water_Program_P = {
  /* Computed Parameter: PCI6251AD_P1_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: channel
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  1.0,

  /* Computed Parameter: PCI6251AD_P2_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: range
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  1.0,

  /* Computed Parameter: PCI6251AD_P3_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: coupling
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  3.0,

  /* Computed Parameter: PCI6251AD_P4_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: scantime
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  5.0E-6,

  /* Computed Parameter: PCI6251AD_P5_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: sampletime
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  0.001,

  /* Computed Parameter: PCI6251AD_P6_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: slot
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  -1.0,

  /* Computed Parameter: PCI6251AD_P7_Size
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  { 1.0, 1.0 },

  /* Expression: boardType
   * Referenced by: '<Root>/PCI-6251 AD'
   */
  51.0,

  /* Expression: 0
   * Referenced by: '<Root>/Memory5'
   */
  0.0,

  /* Computed Parameter: PCI6251DO2_P1_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: channel
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  4.0,

  /* Computed Parameter: PCI6251DO2_P2_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: reset
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  1.0,

  /* Computed Parameter: PCI6251DO2_P3_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: initValue
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  0.0,

  /* Computed Parameter: PCI6251DO2_P4_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: sampletime
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  0.001,

  /* Computed Parameter: PCI6251DO2_P5_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: slot
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  -1.0,

  /* Computed Parameter: PCI6251DO2_P6_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: control
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  8.0,

  /* Computed Parameter: PCI6251DO2_P7_Size
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  { 1.0, 1.0 },

  /* Expression: boardType
   * Referenced by: '<Root>/PCI-6251 DO2'
   */
  51.0
};
